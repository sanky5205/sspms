<?php
$con = mysqli_connect("localhost","root","","test");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $book = '';
  $author = '';
  $booknumber = '';
  //insert query
  if (isset($_POST['insert'])) {
  	$book = $_POST["book"];
  	$author = $_POST["author"];
  	$booknumber = $_POST["booknumber"];
  	if (empty($book)) {
  		echo "enter first name";
  	}elseif (empty($author)) {
  		echo "enter last name";
  	}elseif (empty($booknumber)) {
  		echo "enter booknumber number";
  	}else
	$sql = "INSERT INTO `lib` (book,author,booknumber) VALUES('$book','$author','$booknumber')";
  	if (mysqli_query($con, $sql)=== true) {
               echo "New record created successfully";
            } else {
               echo "Error: " . $sql . "" . mysqli_error($con);
            }
            $con->close();
         }
// select query
 if (isset($_POST['display'])) {
	$sql = 'SELECT * FROM lib';
    $result = mysqli_query($con, $sql);

         if ($result && mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
               echo "book: " . $row["book"]. "<br>";
               echo "author: " . $row["author"]. "<br>";
               echo "booknumber: " . $row["booknumber"]. "<br>";
            }
         } else {
            echo "0 results";
         }
}
//update query
    if (isset($_POST['update'])) {
    	$book = $_POST["book"];
  		$author = $_POST["author"];
  		$booknumber = $_POST["booknumber"];
	if(empty($booknumber))
	{
		echo 'enter user booknumber number  to update';
	} else{
	$sql = "UPDATE `lib` SET  book = '$book', author = '$author', booknumber = '$booknumber' WHERE booknumber = '$booknumber' ";
      if (mysqli_query($con, $sql)) {
      echo "Record updated successfully";
   } else {
      echo "Error updating record: " . mysqli_error($con);
   } 
	}
}
//delete query
 if (isset($_POST['delete'])) {
    $booknumber = $_POST["booknumber"];
	if(empty($booknumber))
	{
		echo 'enter booknumber number to delete';
	} else{
	$sql = "DELETE FROM `lib` WHERE booknumber = '$booknumber'";
      if (mysqli_query($con, $sql)===true) {
      echo "Record deleted successfully";
   } else {
      echo "Error deleting record: " . mysqli_error($con);    }   }   }   ?>