<?php
$con = mysqli_connect("localhost","root","","test");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $fname = '';
  $lname = '';
  $employee_number = '';
  //insert query
  if (isset($_POST['insert'])) {
  	$fname = $_POST["fname"];
  	$lname = $_POST["lname"];
  	$employee_number = $_POST["employee_number"];
  	if (empty($fname)) {
  		echo "enter first name";
  	}elseif (empty($lname)) {
  		echo "enter last name";
  	}elseif (empty($employee_number)) {
  		echo "enter employee_number number";
  	}else
	$sql = "INSERT INTO `studdb` (fname,lname,employee_number) VALUES('$fname','$lname','$employee_number')";
  	if (mysqli_query($con, $sql)=== true) {
               echo "New record created successfully";
            } else {
               echo "Error: " . $sql . "" . mysqli_error($con);
            }
            $con->close();
         }
// select query
 if (isset($_POST['display'])) {
	$sql = 'SELECT * FROM studdb';
    $result = mysqli_query($con, $sql);

         if ($result && mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
               echo "fName: " . $row["fname"]. "<br>";
               echo "lName: " . $row["lname"]. "<br>";
               echo "employee_number: " . $row["employee_number"]. "<br>";
            }
         } else {
            echo "0 results";
         }
}
//update query
    if (isset($_POST['update'])) {
    	$fname = $_POST["fname"];
  		$lname = $_POST["lname"];
  		$employee_number = $_POST["employee_number"];
	if(empty($employee_number))
	{
		echo 'enter user employee_number number  to update';
	} else{
	$sql = "UPDATE `studdb` SET  fname = '$fname', lname = '$lname', employee_number = '$employee_number' WHERE employee_number = '$employee_number' ";
      if (mysqli_query($con, $sql)) {
      echo "Record updated successfully";
   } else {
      echo "Error updating record: " . mysqli_error($con);
   } 
	}
}
//delete query
 if (isset($_POST['delete'])) {
    $employee_number = $_POST["employee_number"];
	if(empty($employee_number))
	{
		echo 'enter employee_number number to delete';
	} else{
	$sql = "DELETE FROM `studdb` WHERE employee_number = '$employee_number'";
      if (mysqli_query($con, $sql)===true) {
      echo "Record deleted successfully";
   } else {
      echo "Error deleting record: " . mysqli_error($con);    }   }   }   ?>